package com.example.doctorstaskmanagerapplication;

public interface CategoriesInterface {

    void onCategoryClick(int position);
}
