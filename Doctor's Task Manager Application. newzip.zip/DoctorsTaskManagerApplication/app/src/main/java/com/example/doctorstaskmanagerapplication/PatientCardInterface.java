package com.example.doctorstaskmanagerapplication;

public interface PatientCardInterface {
    void onPatientClick(int position);
}
